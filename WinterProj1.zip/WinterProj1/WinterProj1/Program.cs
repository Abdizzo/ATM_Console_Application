﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;

public class cardHolder
{
    String cardNum;
    int pin;
    String firstName;
    String lastName;
    double balance;

    public cardHolder(string cardNum, int pin, string firstName, string lastName, double balance)
    {
        this.cardNum = cardNum;
        this.pin = pin;
        this.firstName = firstName;
        this.lastName = lastName;
        this.balance = balance;
    }
    public String getCardnum()
    {
        return cardNum;
    }
    public int getPin()
    {
        return pin;
    }
    public String getFirstname()
    {
        return firstName;
    }
    public String getLastname()
    {
        return lastName;
    }
    public double getbalance() 
    { 
        return balance; 
    }

    public void setNum(String newCardnum) 
    { 
        cardNum = newCardnum;
    }
    public void setPin(int newPin) 
    {
        pin = newPin;
    }
    public void setFirstName(String newFirstName)
    {
        firstName = newFirstName;
    }
    public void setLastName(String newLastName)
    {
        lastName = newLastName;
    }
    public void setBalance(double newBalance)
    {
        balance = newBalance;
    }
    public static void Main(String[] args)
    {
        void printOptions()
        {
            Console.WriteLine("Please choose from one of the following options... ");
            Console.WriteLine("1. Deposit");
            Console.WriteLine("2. Withdraw");
            Console.WriteLine("3. show balance");
            Console.WriteLine("4. Exit");


        }

        void deposit(cardHolder currentUser)
        {
            Console.WriteLine("how much $$ would you like to deposit? ");
            double deposit = Double.Parse(Console.ReadLine());
            currentUser.setBalance(currentUser.getbalance() + deposit);
            Console.WriteLine("thank you for your $$. your new balance is: " + currentUser.getbalance());

        }
        void withdraw(cardHolder currentUser)
        {
            Console.WriteLine("how much $$ would you like to withdraw: ");
            double withdrawal = Double.Parse(Console.ReadLine());

            if(currentUser.getbalance() < withdrawal)
            {
                Console.WriteLine("Insufficient balance :(");

            }
            else
            {
                currentUser.setBalance(currentUser.getbalance() - withdrawal);
                Console.WriteLine("you're good to go! Thank you :)");

            }
        }

        void balance(cardHolder currentUser)
        {
            Console.WriteLine("current balance: " + currentUser.getbalance());
        }

        List<cardHolder> cardHolders = new List<cardHolder>();
        cardHolders.Add(new cardHolder("4485579643090284", 6577, "john", "griffith", 699.35));
        cardHolders.Add(new cardHolder("4485577766728425", 1661, "jose", "enrique", 744.51));
        cardHolders.Add(new cardHolder("4485577570293962", 8096, "lauren", "vexler", 730.2));
        cardHolders.Add(new cardHolder("4485576391387599", 1110, "karlo", "patro", 970.3));
        cardHolders.Add(new cardHolder("4485577999801809", 3860, "maddy", "brown", 678.20));

        //prompt user

        Console.WriteLine("welcome to magusaATM");
        Console.WriteLine("please insert your debit card: ");
        String debitCardNum = "";
        cardHolder currentUser;


        while (true)
        {
            try
            {
                debitCardNum = Console.ReadLine();

                currentUser = cardHolders.FirstOrDefault(a => a.cardNum == debitCardNum);
                if (currentUser != null) { break; }
                else { Console.WriteLine("card not recognized. please try again"); }


            }
            catch { Console.WriteLine("card not recognized. please try again"); }

        }

        Console.WriteLine("please enter your pin: ");
        int userPin = 0;
        while (true)
        {
            try
            {
                userPin = int.Parse(Console.ReadLine());
                if (currentUser.getPin() == userPin) { break; }
                else { Console.WriteLine("Incorrect pin. please try again."); }


            }
            catch { Console.WriteLine("Incorrect pin. please try again."); }

        }

        Console.WriteLine("welcome " + currentUser.getFirstname() + ":)");
        int option = 0;
        do
        {
            printOptions();
            try
            {
                option = int.Parse(Console.ReadLine());
            }
            catch { }
            if(option == 1) { deposit(currentUser); }
            else if(option == 2) { withdraw(currentUser); }
            else if(option == 3) { balance(currentUser); }
            else if(option == 4) { break; }
            else { option= 0; }

           

        }
        

        while (option != 4);
        Console.WriteLine("thank you! have a nice day :)");



    }
}





